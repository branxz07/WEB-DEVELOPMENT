const https = require("https");
const express =require("express");
const { response } = require("express");
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static("public"));
app.engine("html", require("ejs").renderFile); 
app.set("view engine", "html");

var images_names = [];
var images_url = [];
var characters = [{
    ID: "",
    first_name: "",
    last_name: "",
    born: "",
    dead: "",
    title: "",
    Aliases: "",
    Name: ""
    /*Family: "",
    Family_crest: ""*/
}];
var Ya_esta_mostrando = false;
var pos2 = 0;

var comes_next = false;
var comes_previous = false;


app.get("/",(req, res) =>{
    res.sendFile(__dirname + "/index.html");
});
app.post('/',(req, res) =>{
    if(Ya_esta_mostrando == false){
        images_names = [];
        images_url = [];
        characters = [{
            ID: "",
            first_name: "",
            last_name: "",
            born: "",
            dead: "",
            title: "",
            Aliases: "",
            Name: ""
            /*Family: "",
            Family_crest: ""*/
        }];
        for(var i = 1; i <= 43; i++){
            var url = "https://www.anapioficeandfire.com/api/characters?page=" + i.toString() + "&pageSize=50";
            https.get(url, (response) => {
                var data = "";
                response.on("data", (jdata) =>{
                    data += jdata;
                })
                .on("end", () => {
                    jsonData= JSON.parse(data);
                    if(jsonData[0]["url"] == "https://www.anapioficeandfire.com/api/characters/2105"){
                        var variable = 34;
                    }
                    else{
                        var variable = 50;
                    }

                    for(var j = 0; j < variable; j++){
                        var id_temp = jsonData[j]["url"];
                        var id_temp2 = id_temp.slice(49);
                        var name = jsonData[j]["name"];
                        var FLName = name.split(' ');
                        if(FLName.length == 0){
                            var FName = "";
                            var LName = "";
                        }else if(FLName.length == 1){
                            var FName = FLName[0];
                            var LName = "";
                        }else{
                            var FName = FLName[0];
                            var LName = FLName[1];
                        }
                        var born_d = jsonData[j]["born"];
                        var dead_d = jsonData[j]["died"];
                        var titles_temp = jsonData[j]["titles"];
                        var Aliases_temp = jsonData[j]["aliases"];
                        characters.push({ID: id_temp2, first_name: FName, last_name: LName, born: born_d, dead: dead_d, title: titles_temp, Aliases: Aliases_temp, Name: name});
                    }
                })
                .on("error",(e)=>{
                    console.log("Error ${e.message}");
                });
            });
        }
        https.get("https://thronesapi.com/api/v2/Characters", (response) => {
            response.on("data", (jdata) =>{
                jsonData= JSON.parse(jdata);
                for(var i = 0; i < 53; i++){
                    images_names.push(jsonData[i]["fullName"]);
                    images_url.push(jsonData[i]["imageUrl"]);
                }
            })
            .on("error",(e)=>{
                console.log("Error ${e.message}");
            });
        });
        
        const name = req.body.fName;
        var Si_Esta = false;

        setTimeout(function () {
            var pos = 0;
            for(var i = 0; i < characters.length; i++){
                if(name == characters[i].Name){
                    Si_Esta = true;
                    pos = i;
                    pos2 = i;
                }
                if(Si_Esta == true){
                    break;
                }
            }
            
            if(Si_Esta == true){
                if(images_names.includes(name)){
                    for(var i = 0; i < characters.length; i++){
                        if(name == images_names[i]){
                            var link = images_url[i];
                        }
                    }
                    res.render(__dirname + "/character.html", {url: link, ID: characters[pos].ID, FName: characters[pos].first_name, 
                    LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
                }
                else{
                    res.render(__dirname + "/character.html", {url: "", ID: characters[pos].ID, FName: characters[pos].first_name, 
                    LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
                }
            }
            else{
                res.render(__dirname + "/error.html")
            }
        }, 3000);
        Ya_esta_mostrando = true;
    }
    else{
        const name = req.body.fName;
        var Si_Esta = false;
        var pos = 0;
        for(var i = 0; i < characters.length; i++){
            if(name == characters[i].Name){
                Si_Esta = true;
                pos = i;
            }
            if(Si_Esta == true){
                break;
            }
        }
        
        if(Si_Esta == true){
            if(images_names.includes(name)){
                for(var i = 0; i < characters.length; i++){
                    if(name == images_names[i]){
                        var link = images_url[i];
                    }
                }
                res.render(__dirname + "/character.html", {url: link, ID: characters[pos].ID, FName: characters[pos].first_name, 
                LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
            }
            else{
                res.render(__dirname + "/character.html", {url: "", ID: characters[pos].ID, FName: characters[pos].first_name, 
                LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
            }
        }
        else{
            res.render(__dirname + "/error.html")
        }
    }
});

app.get("/next",(req, res) =>{
    if(pos2 == 2134){   
        pos2 = 0;
    }
    if(comes_previous == true){
        if(pos2 == 2133){   
            pos2 = 0;
        }
        pos2 += 2;
    }else{
        pos2++;
    }
    comes_next = true;
    comes_previous = false;
    const name = characters[pos2].Name;
    var Si_Esta = false;
    var pos = 0;
    for(var i = 0; i < characters.length; i++){
        if(name == characters[i].Name){
            Si_Esta = true;
            pos = i;
        }
        if(Si_Esta == true){
            break;
        }
    }
    if(Si_Esta == true){
        if(images_names.includes(name)){
            for(var i = 0; i < characters.length; i++){
                if(name == images_names[i]){
                    var link = images_url[i];
                }
            }
            res.render(__dirname + "/character.html", {url: link, ID: characters[pos].ID, FName: characters[pos].first_name, 
            LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
        }
        else{
            res.render(__dirname + "/character.html", {url: "", ID: characters[pos].ID, FName: characters[pos].first_name, 
            LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
        }
    }
    else{
        res.render(__dirname + "/error.html")
    }
});
app.get("/previous",(req, res) =>{
    if(pos2 == 0){    
        pos2 = 2135;
    }
    if(comes_next == true){
        if(pos2 == 1){    
            pos2 = 2135;
        }
        pos2 -= 2;
    }else{
        pos2--;
    }
    comes_previous = true;
    comes_next = false;
    const name = characters[pos2].Name;
    var Si_Esta = false;
    var pos = 0;
    for(var i = 0; i < characters.length; i++){
        if(name == characters[i].Name){
            Si_Esta = true;
            pos = i;
        }
        if(Si_Esta == true){
            break;
        }
    }
    if(Si_Esta == true){
        if(images_names.includes(name)){
            for(var i = 0; i < characters.length; i++){
                if(name == images_names[i]){
                    var link = images_url[i];
                }
            }
            res.render(__dirname + "/character.html", {url: link, ID: characters[pos].ID, FName: characters[pos].first_name, 
            LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
        }
        else{
            res.render(__dirname + "/character.html", {url: "", ID: characters[pos].ID, FName: characters[pos].first_name, 
            LName: characters[pos].last_name, Born: characters[pos].born, Dead: characters[pos].dead, Titles: characters[pos].title, Aliases: characters[pos].Aliases});
        }
    }
    else{
        res.render(__dirname + "/error.html")
    }
});

app.listen(3000, () => {
    console.log("Listening on port 3000, Hello World");
});

